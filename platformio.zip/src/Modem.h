#pragma once

class Modem
{
    public:
        bool begin();
};
extern Modem modem;
extern TinyGsm modem;