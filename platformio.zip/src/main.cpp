#include <Arduino.h>

#include "Display.h"
#include "Temperature.h"
#include "Modem.h"

Temperature temp;

void setup()
{
    Serial.begin(115200);

    oled.begin();

    if (!temp.begin())
    {
        Serial.println("Temperature sensor not found!");
    }

    oled.bootScreen();

    delay(1500);

    if (modem.begin())
{
    Serial.println("Modem OK");
}
else
{
    Serial.println("Modem FAILED");
}
if (mqtt.begin())
{
    Serial.println("MQTT OK");
}
else
{
    Serial.println("MQTT FAILED");
}
}

void loop()
{
    float t = temp.getFahrenheit();

    Serial.printf("Ambient: %.1f F\n", t);

    oled.status(
        "Camper Monitor",
        "Ambient",
        String(t, 1) + " F");

    delay(1000);
  mqtt.loop();

static unsigned long lastPublish = 0;

if (millis() - lastPublish > 30000)
{
    lastPublish = millis();

    float t = temp.getFahrenheit();

    mqtt.publishAmbient(t);

    Serial.println("Published temperature");
}  
}