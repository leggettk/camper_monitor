#pragma once

// Cellular
#define APN "hologram"
#define APN_USER ""
#define APN_PASS ""

// MQTT
#define MQTT_HOST "kt4bn.duckdns.org"
#define MQTT_PORT 8883

#define MQTT_USER "camper_monitor"
#define MQTT_PASSWORD "Kt4bn?001"

#define MQTT_CLIENT_ID "camper-monitor-01"